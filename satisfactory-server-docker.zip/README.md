# Satisfactory Server Game

## Liberação do Firewall 

### Windows

```ps1
New-NetFirewallRule -DisplayName "Allow Satisfactory default inbound ports" -Direction Inbound -Action Allow -EdgeTraversalPolicy Allow -Protocol UDP -LocalPort 15000,15777,7777
```

### Linux

## Build

```sh
docker build -t satisfactory-server .
```

## Execução do container

```sh
docker run -d -p 7777:7777/udp -p 15000:15000/udp -p 15777:15777/udp -v E:\\SATISFACTORY_SERVER_CONTAINER:/satisfactory/saved --name satisfactory satisfactory-server
```