#!/bin/bash

# Diretório onde o jogo está instalado
GAME_DIR="/satisfactory"

# Comando para atualizar o jogo (substitua conforme o gerenciador que você usa, como SteamCMD)
echo "Atualizando o servidor Satisfactory..."
#steamcmd +login anonymous +force_install_dir "$GAME_DIR" +app_update 1690800 validate +quit
/steamcmd/steamcmd.sh +login anonymous +force_install_dir /satisfactory +app_update 1690800 validate +quit
chmod +x /satisfactory/FactoryServer.sh

echo "Atualização concluída. Iniciando o servidor Satisfactory..."

# Inicia o servidor do jogo
cd "$GAME_DIR"
./FactoryServer.sh -log